```python
from selenium import webdriver

driver=webdriver.Chrome()
```


```python
driver.get('https://www.instagram.com/')#link of the web site to be scraped
```


```python
from selenium.webdriver.common.by import By
#locating the username and password block
login=driver.find_element(By.CLASS_NAME, '_aa48')
pas=driver.find_elements(By.CLASS_NAME, '_aa48')
pas=pas[1]
print(login,pas)
```

    <selenium.webdriver.remote.webelement.WebElement (session="d6b9e9a26e7fabb547d36cdc6af58e8a", element="e7a771a0-2d8e-47c1-aeec-cee8c4c521be")> <selenium.webdriver.remote.webelement.WebElement (session="d6b9e9a26e7fabb547d36cdc6af58e8a", element="bc03920b-c8ed-475b-839a-665232179e56")>
    


```python
#PROVIDING THE LOGIN CREDENTIALS
login.send_keys('SAMPLE USERNAME')
pas.send_keys('SAMPLE PASSWORD')
```


```python
#SUBMITTING THE INFO
pas.submit()
```


```python
#A CHECK BOX APPEARED TO SAVE THE LOGIN DETAILS AND I SELECTEC NO BUTTON
btn=driver.find_elements(By.CLASS_NAME, '_acan')
btn=btn[1]
```


```python
#CLICKED THE BUTTON
btn.click()
```


```python
#ANOTHER CHECK BOX APPEARED ABOUT MESSAGES I SELECTED NO
btn=driver.find_elements(By.CLASS_NAME, '_a9--')
btn=btn[1]
```


```python
btn.click()
```


```python
#SEARCHED THE SEARCH BUTTON AND CLICKED ON IT
sbtn=driver.find_elements(By.CLASS_NAME, 'x1i10hfl')
sbtn[2].click()
```


```python

```


```python
#FINDING THE SEARCH BOX
search=driver.find_element(By.CLASS_NAME, '_aauy')
search
```




    <selenium.webdriver.remote.webelement.WebElement (session="2ba3c5bec0c442f000159de0fe65fa55", element="ada2af30-e5ad-4120-8127-903965b37cb6")>




```python
#TYPING THE REQ SEARCH TEXT
search.send_keys('food')
```


```python
#REMOVINGS THE TAGS AND SOME OTHER UNWANTED IDS
users=driver.find_elements(By.CLASS_NAME, '_aacw')
users=users[:-28]
```


```python
#FINDING ALL THE USERS AND PRINTING THEIR NAMES
for i in users:
    s=str(i.text)
    if(len(s)==0):
        continue
    else:
        if s[0]!="#":
            print(s)
```

    Search
    food.fashion.drama
    foodalicious_foodies
    food_trove
    keurig_kiit_
    food.bynini_
    pepper_.pots
    travel_food_love__
    foodfindo
    ap_fooddiaries
    food_and_them_
    foodies_of_bhubaneswar
    food_heart09
    foodinodisha
    foodio_therapy
    cuttack_food_love
    foodpandits
    __.fusion.__food
    _cuttack_food_diaries_
    foodstories_27
    _.moodyfoody._
    freesoulfoodies
    _.the_foodies._
    memories_of_meals
    place_for_foodies_
    food_mehkma
    swaad_gwalior_ke
    _cuttack.diary_
    dilsefoodie
    foodgasm.bhilai
    punefoodiesoul
    foodie_ayush05
    foodiee_fitso_
    food_food_food_fooooood
    dfc_dadabiryani
    foodiebyheart2.0
    theedibletripper
    _food.corner_29
    odiafoodfeeds
    food.moitro
    street_food_chandigarh
    foodestia
    food_fotu_fantasy
    foodies_odisha
    food_fiesta___
    food_b.a.e
    cuttack_food_point
    food_raasta
    foodie_odisha_
    Food Mantra, Odisha
    mr_.foodie._0_1
    foodncate
    idiotic_sperm
    _bikasshhh._
    25,313 others
    idiotic_sperm
    23h_left_123
    Post
    haikyuuangels
    


```python
#CLEARING THE SEARCH
search.clear()
```


```python
search=driver.find_element(By.CLASS_NAME, '_aauy')
search
```




    <selenium.webdriver.remote.webelement.WebElement (session="2ba3c5bec0c442f000159de0fe65fa55", element="f2573f19-b7d7-4836-9d98-a5c961ede471")>




```python
#NEW SEARCH
search.send_keys('So Delhi')
```


```python
#CLICKING ON THE ID THAT WE WANT TO SCRAPE
cl=driver.find_element(By.CLASS_NAME, '_aarf')
cl
```




    <selenium.webdriver.remote.webelement.WebElement (session="2ba3c5bec0c442f000159de0fe65fa55", element="782e39dd-f425-480d-903a-b2147f3244a2")>




```python
cl.click()
```


```python
#SEARCHING THE FOLLOW BUTTON AND THEN FOLLOWED THE ID
follow=driver.find_element(By.CLASS_NAME, '_acan')
```


```python
follow.click()
```


```python
#UNFOLLOW CANT BE DONE ON PC
#follow=driver.find_element(By.CLASS_NAME, '_acan')
#follow.click()
```


```python
driver.back()
```


```python
search=driver.find_elements(By.CLASS_NAME, 'x1i10hfl')
search[2].click()
```


```python
search=driver.find_element(By.CLASS_NAME, '_aauy')
```


```python
#NEW SEARCH
search.send_keys('dilsefoodie')
```


```python
cl=driver.find_element(By.CLASS_NAME, '_aarf')
```


```python
cl.click()
```


```python
#GETTING THE LINKS OF ALL THE POSTS AND STORED IT IN AN ARRAY
postcl=driver.find_elements(By.CLASS_NAME, 'x1iyjqo2')
c1=postcl[3].find_elements(By.CLASS_NAME, '_a6hd')
urls=[]
for i in c1:
    urls.append(i.get_attribute('href'))
urls
```




    (['https://www.instagram.com/p/ClOEaKloSqf/',
      'https://www.instagram.com/p/ClIpBi1oytH/',
      'https://www.instagram.com/p/ClD_qvjKzWm/',
      'https://www.instagram.com/p/ClDVGLrK0iD/',
      'https://www.instagram.com/p/ClBFqoSI6YY/',
      'https://www.instagram.com/p/Ck-sLTTIbB9/',
      'https://www.instagram.com/p/Ck7nEEPqjfv/',
      'https://www.instagram.com/p/Ck5wEyvICyO/',
      'https://www.instagram.com/p/Ck5DdYqon57/',
      'https://www.instagram.com/p/Ck0l1BcKHno/',
      'https://www.instagram.com/p/Ckx01RhIbRv/',
      'https://www.instagram.com/p/CkvkzsmoRmq/',
      'https://www.instagram.com/p/CkvS87GoPRB/',
      'https://www.instagram.com/p/CksW_9_Ikeu/',
      'https://www.instagram.com/p/CksKglkoKxf/',
      'https://www.instagram.com/p/Ckqa8wzpPVy/',
      'https://www.instagram.com/p/CkqGWB1qnQs/',
      'https://www.instagram.com/p/Cki00-aIMpW/',
      'https://www.instagram.com/p/Ckh_be7qZoF/',
      'https://www.instagram.com/p/CkgCA8cK6Cv/',
      'https://www.instagram.com/p/CkdKChwIrk9/',
      'https://www.instagram.com/p/CkZ3Oh-IoUz/',
      'https://www.instagram.com/p/CkTFOL0KAVP/',
      'https://www.instagram.com/p/CkQyk1KIrk_/'],
     40)




```python
#WENT TO EACH URL AND LIKE THE FIRST 30 POSTS AND THEN UNLIKED IT
c=0
for i in urls:
    if c==30:
        break
    driver.get(i)
    driver.implicitly_wait(5)
    like=driver.find_element(By.CLASS_NAME,'_aamw')
    like=like.find_element(By.TAG_NAME,'button')
    like.click()
    driver.back()
    driver.implicitly_wait(5)
    c+=1
```


```python
#GOING BACK TO THE PREVIOUS PAGE
driver.back()
```


```python
search=driver.find_elements(By.CLASS_NAME, 'x1i10hfl')
search[2].click()
```


```python
search=driver.find_element(By.CLASS_NAME, '_aauy')
```


```python
#NEW SEARCH
search.send_keys('foodtalkindia')
```


```python
cl=driver.find_element(By.CLASS_NAME, '_aarf')
```


```python
cl.click()
```


```python
#LOCATING THE FOLLOWERS BUTTON
followers_button=driver.find_elements(By.CLASS_NAME, 'xl565be')
a=followers_button[1].find_element(By.TAG_NAME, 'a')
link=a.get_attribute('href')
link
```




    'https://www.instagram.com/foodtalkindia/followers/'




```python
#SCRAPING THE FOLLOWERS LINK
driver.get(link)
```


```python
#TEST CODE FOR ACCESSING THE USERNAME
followers=driver.find_element(By.CLASS_NAME, '_aano')
follow=followers.find_elements(By.CLASS_NAME, '_ab9-')
```




    'kali.a2287'




```python
#PRINTING THE NAME OF ALL THE FOLLOWERS
for i in follow:
    s=i.find_element(By.CLASS_NAME, '_ab9o').text
    print(s)
#BY DEFAULT INSTAGRAM ALLOWS ONLY TO VIEW SOME OF THE USERS AND DOESNT ALLOW TO VIEW ALL THE FOLLOWERS 
#no common followers
```

    kali.a2287
    vivekjamucha
    yuktigrover__
    *
    varun_____aa
    _ ★꧁༒•kunal•༒꧂
    _usman_dx_tara_yaar
    _mohd_ Usman_ rangrej
    jungskookie_97
    _•Candyhearts•_
    aamer2118
    aamer Qureshi
    fanta_sticallyme
    Aditya 🙂
    abinjrajka
    Akansha Binjrajka
    anand_mohan
    Anand Mohan
    ___anant___03
    Anant
    ashishkotawala
    Ashish Goyal
    windowseatdog
    Avleen Kaur Lamba
    cheflinkequipment
    Chef Link
    coolsprks
    Coolsprks
    _donutfactory_
    Donut Factory
    lolwah_real_estate
    Dubai Real Estate 💚🇸🇦💚
    eco_cosmos
    ECO COSMOS
    fameela_meeran
    fameela meeran
    food_fudge
    Faraz
    naninani26008
    Gul Firdosh
    heyitscrazyhere
    heyitscrazyhere
    ishaan.pandey
    Ishaan Pandey
    jesusimmanuel13579
    Jesus Immanuel
    kapilas.das.12
    Kapilas Das
    bharadwaj.karan
    Karan Bharadwaj
    manojsethi65
    Manoj Sethi
    mayank_chadha
    Mayank Chadha
    meghapari
    Meghapari💕🧿
    miraalvialvi
    Mira Alvi Alvi
    mitulshah91
    Mitul Shah
    nanditagaur05
    Nandita Gaur
    devganpooja
    Pooja Devgan
    richashukla10
    Richa Shukla
    rupesh.jaiswal.rj
    Rupesh Jaiswal
    gsk_silentkiller
    Sai Krishna Gsk Edits
    its_sayali_13
    Sayali Patil🌸
    solankisachin172
    Solanki Sachin
    soundarya9877
    soundarya
    srishtichimnani
    Srishti Chimnani
    subhenduchandrasaha
    Subhendu Chandra Saha
    urvaz_k
    URVAZ
    pillayviki
    Viju Pillay
    yamini.s.m
    Yamini S M
    yashikadewan_itzme12
    Yashika Dewan
    shikha.s__00
    शिखा 🦋
    esha__mali__
    এষা মালি ✨
    thoavootsqa
    吉村めい
    official_ankit78600
    🇦‌🇳‌🇰‌🇮‌🇹‌
    


```python
driver.back()
```


```python
search=driver.find_elements(By.CLASS_NAME, 'x1i10hfl')
search[2].click()
```


```python
search=driver.find_element(By.CLASS_NAME, '_aauy')
```


```python
#NEW SEARCH
search.send_keys('coding.ninjas')
```


```python
#THIS PROCESS CAN BE USED FOR BOTH CASES WHEN STORY IS VIEWED AND EVEN WHEN THE STORY IS NOT VIEWED AND IF THERE IS NO STORY
#THEN WE CANNOT VIEW IT
cl=driver.find_element(By.CLASS_NAME, '_aarf')
```


```python
cl.click()
```
